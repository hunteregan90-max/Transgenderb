from fastapi import FastAPI, HTTPException, Header, Depends, Request
from pydantic import BaseModel, Field
from datetime import datetime, timezone, timedelta
import json, hashlib, time
from .db import init, conn
from .security import hash_password, verify_password, invite_token, invite_hash, issue_jwt, decode_jwt, fernet_from_env

app=FastAPI(title='Private Wellness API',version='0.1.0')
FERNET=fernet_from_env()
RANK_CAPS={'XXX':2,'XX':3,'X':4}
LOWER_RANKS=['Senior Officer','Officer','Community Guardian','Moderator','Support Leader','Group Leader','Verified Member','Member','New Member']

@app.on_event('startup')
def startup(): init()

class Register(BaseModel): invite_code:str=Field(min_length=35,max_length=35); username:str=Field(min_length=3,max_length=40); password:str=Field(min_length=10,max_length=200); display_name:str=Field(min_length=1,max_length=80)
class BootstrapReq(BaseModel): username:str=Field(min_length=3,max_length=40); password:str=Field(min_length=12,max_length=200); display_name:str=Field(min_length=1,max_length=80)
class Login(BaseModel): username:str; password:str
class InviteReq(BaseModel): hours_valid:int=Field(default=168,ge=1,le=8760)
class RankReq(BaseModel): rank:str
class ResponseReq(BaseModel): question_id:str=Field(pattern=r'^(TM|TW|MH)-\d{3}$'); value:object
class PostReq(BaseModel): body:str=Field(min_length=1,max_length=20000); visibility:str='community'
class ReportReq(BaseModel): post_id:int|None=None; reason:str=Field(min_length=3,max_length=1000)

def audit(actor,action,target_type=None,target_id=None,detail=None):
 c=conn(); c.execute('INSERT INTO audit(actor_id,action,target_type,target_id,detail) VALUES(?,?,?,?,?)',(actor,action,target_type,str(target_id) if target_id is not None else None,detail)); c.commit(); c.close()

def current_user(authorization:str|None=Header(default=None)):
 if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Authentication required')
 try: uid=decode_jwt(authorization[7:])
 except Exception: raise HTTPException(401,'Invalid or expired session')
 c=conn(); u=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone(); c.close()
 if not u or u['status']!='active': raise HTTPException(403,'Account unavailable')
 return dict(u)

def require_rank(*ranks):
 def dep(u=Depends(current_user)):
  if u['rank'] not in ranks: raise HTTPException(403,'Insufficient role')
  return u
 return dep

def blocked_invite_attempt(key_hash):
 cutoff=int(time.time())-900; c=conn(); n=c.execute('SELECT COUNT(*) n FROM login_attempts WHERE kind="invite" AND key_hash=? AND success=0 AND created_at>?',(key_hash,cutoff)).fetchone()['n']; c.close(); return n>=8

def record_attempt(kind,key_hash,success):
 c=conn(); c.execute('INSERT INTO login_attempts(kind,key_hash,success,created_at) VALUES(?,?,?,?)',(kind,key_hash,1 if success else 0,int(time.time()))); c.commit(); c.close()

@app.get('/health')
def health(): return {'ok':True,'service':'private-wellness-api'}

@app.post('/admin/bootstrap')
def bootstrap(req:BootstrapReq, owner_secret:str=Header(alias='X-Bootstrap-Secret',default='')):
 expected=__import__('os').getenv('BOOTSTRAP_SECRET')
 if not expected or owner_secret!=expected: raise HTTPException(403,'Bootstrap disabled or secret incorrect')
 c=conn(); count=c.execute('SELECT COUNT(*) n FROM users').fetchone()['n']
 if count: c.close(); raise HTTPException(409,'Already bootstrapped')
 if c.execute('SELECT 1 FROM users WHERE username=?',(req.username,)).fetchone(): c.close(); raise HTTPException(409,'Username already exists')
 ph=hash_password(req.password); c.execute('INSERT INTO users(membership_no,username,display_name,password_hash,rank) VALUES(?,?,?,?,?)',('MEM-000001',req.username,req.display_name,ph,'XXX')); uid=c.execute('SELECT last_insert_rowid() id').fetchone()['id']; c.commit(); c.close(); audit(uid,'bootstrap_owner','user',uid,'Original creator account created as XXX.'); return {'membership_no':'MEM-000001','user_id':uid,'rank':'XXX','access_token':issue_jwt(uid),'token_type':'bearer'}

@app.post('/admin/invites')
def create_invite(req:InviteReq,u=Depends(require_rank('XXX','XX'))):
 token=invite_token(); h=invite_hash(token); exp=(datetime.now(timezone.utc)+timedelta(hours=req.hours_valid)).isoformat(); c=conn(); c.execute('INSERT INTO invites(token_hash,created_by,expires_at) VALUES(?,?,?)',(h,u['id'],exp)); iid=c.execute('SELECT last_insert_rowid() id').fetchone()['id']; c.commit(); c.close(); audit(u['id'],'create_invite','invite',iid); return {'invite_code':token,'length':len(token),'expires_at':exp,'display_once':True}


@app.get('/admin/invites')
def list_invites(status:str|None=None,u=Depends(require_rank('XXX','XX'))):
 c=conn(); rows=c.execute('SELECT id,created_by,created_at,expires_at,used_at,revoked_at FROM invites ORDER BY id DESC LIMIT 500').fetchall(); c.close(); now=datetime.now(timezone.utc); out=[]
 for r in rows:
  if r['revoked_at']: st='revoked'
  elif r['used_at']: st='used'
  elif r['expires_at'] and datetime.fromisoformat(r['expires_at'])<=now: st='expired'
  else: st='active'
  if status and st!=status: continue
  out.append({'id':r['id'],'created_by':r['created_by'],'created_at':r['created_at'],'expires_at':r['expires_at'],'used_at':r['used_at'],'revoked_at':r['revoked_at'],'status':st})
 return out

@app.delete('/admin/invites/{invite_id}')
def revoke_invite(invite_id:int,u=Depends(require_rank('XXX','XX'))):
 c=conn(); c.execute('UPDATE invites SET revoked_at=CURRENT_TIMESTAMP WHERE id=?',(invite_id,)); c.commit(); c.close(); audit(u['id'],'revoke_invite','invite',invite_id); return {'ok':True}

@app.post('/auth/register')
def register(req:Register, request:Request):
 h=invite_hash(req.invite_code)
 if blocked_invite_attempt(h): raise HTTPException(429,'Too many failed invitation attempts. Try later.')
 c=conn(); inv=c.execute('SELECT * FROM invites WHERE token_hash=?',(h,)).fetchone()
 valid=bool(inv and not inv['used_at'] and not inv['revoked_at'] and (not inv['expires_at'] or datetime.fromisoformat(inv['expires_at'])>datetime.now(timezone.utc)))
 record_attempt('invite',h,valid)
 if not valid: c.close(); raise HTTPException(400,'Invitation is invalid, expired, revoked, or already used')
 if c.execute('SELECT 1 FROM users WHERE username=?',(req.username,)).fetchone(): c.close(); raise HTTPException(409,'Username already exists')
 next_id=c.execute('SELECT COALESCE(MAX(id),0)+1 n FROM users').fetchone()['n']; mem=f'MEM-{next_id:06d}'; rank='Member'
 c.execute('INSERT INTO users(membership_no,username,display_name,password_hash,rank) VALUES(?,?,?,?,?)',(mem,req.username,req.display_name,hash_password(req.password),rank)); uid=c.execute('SELECT last_insert_rowid() id').fetchone()['id']; c.execute('UPDATE invites SET used_at=CURRENT_TIMESTAMP WHERE id=?',(inv['id'],)); c.commit(); c.close(); audit(uid,'register','user',uid); return {'access_token':issue_jwt(uid),'token_type':'bearer','membership_no':mem,'rank':rank}

@app.post('/auth/login')
def login(req:Login):
 c=conn(); u=c.execute('SELECT * FROM users WHERE username=?',(req.username,)).fetchone(); c.close()
 if not u or not verify_password(u['password_hash'],req.password) or u['status']!='active': raise HTTPException(401,'Invalid credentials')
 return {'access_token':issue_jwt(u['id']),'token_type':'bearer','membership_no':u['membership_no'],'rank':u['rank']}

@app.get('/me')
def me(u=Depends(current_user)): return {k:u[k] for k in ['id','membership_no','username','display_name','rank','status','created_at']}

@app.patch('/admin/users/{user_id}/rank')
def set_rank(user_id:int,req:RankReq,u=Depends(require_rank('XXX','XX'))):
 rank=req.rank; c=conn(); target=c.execute('SELECT id,rank,status FROM users WHERE id=?',(user_id,)).fetchone(); c.close()
 if not target: raise HTTPException(404,'User not found')
 if target['rank']=='XXX' and u['rank']!='XXX': raise HTTPException(403,'Only XXX can change an XXX account')
 if rank in ('XXX','XX') and u['rank']!='XXX': raise HTTPException(403,'Only XXX can appoint XXX or XX')
 if rank=='XXX' and u['rank']!='XXX': raise HTTPException(403,'Only XXX can appoint XXX')
 if target['rank']==rank: return {'ok':True,'rank':rank}
 if rank in ('XXX','XX','X'):
  cap=RANK_CAPS[rank]; c=conn(); n=c.execute('SELECT COUNT(*) n FROM users WHERE rank=? AND status="active"',(rank,)).fetchone()['n']; c.close();
  if n>=cap: raise HTTPException(409,f'{rank} cap of {cap} reached')
 elif rank not in LOWER_RANKS: raise HTTPException(400,'Unknown rank')
 c=conn(); c.execute('UPDATE users SET rank=? WHERE id=?',(rank,user_id)); c.commit(); c.close(); audit(u['id'],'set_rank','user',user_id,rank); return {'ok':True,'rank':rank}

@app.put('/responses')
def put_response(req:ResponseReq,u=Depends(current_user)):
 blob=FERNET.encrypt(json.dumps(req.value,ensure_ascii=False).encode())
 c=conn(); c.execute('INSERT INTO responses(user_id,question_id,ciphertext) VALUES(?,?,?) ON CONFLICT(user_id,question_id) DO UPDATE SET ciphertext=excluded.ciphertext,updated_at=CURRENT_TIMESTAMP',(u['id'],req.question_id,blob)); c.commit(); c.close(); return {'ok':True}

@app.get('/responses')
def get_responses(u=Depends(current_user)):
 c=conn(); rows=c.execute('SELECT question_id,ciphertext,updated_at FROM responses WHERE user_id=?',(u['id'],)).fetchall(); c.close(); out=[]
 for r in rows:
  try: value=json.loads(FERNET.decrypt(r['ciphertext']).decode())
  except Exception: value=None
  out.append({'question_id':r['question_id'],'value':value,'updated_at':r['updated_at']})
 return out

@app.post('/posts')
def create_post(req:PostReq,u=Depends(current_user)):
 if req.visibility not in ['only_me','selected_contacts','friends','selected_group','leadership','community','custom']: raise HTTPException(400,'Invalid visibility')
 blob=FERNET.encrypt(req.body.encode()); c=conn(); c.execute('INSERT INTO posts(user_id,body_ciphertext,visibility) VALUES(?,?,?)',(u['id'],blob,req.visibility)); pid=c.execute('SELECT last_insert_rowid() id').fetchone()['id']; c.commit(); c.close(); return {'id':pid,'visibility':req.visibility}

@app.post('/reports')
def report(req:ReportReq,u=Depends(current_user)):
 c=conn(); c.execute('INSERT INTO reports(reporter_id,post_id,reason) VALUES(?,?,?)',(u['id'],req.post_id,req.reason)); rid=c.execute('SELECT last_insert_rowid() id').fetchone()['id']; c.commit(); c.close(); audit(u['id'],'report','report',rid); return {'id':rid,'status':'open'}

@app.get('/admin/audit')
def get_audit(u=Depends(require_rank('XXX','XX'))):
 c=conn(); rows=[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 500').fetchall()]; c.close(); return rows
