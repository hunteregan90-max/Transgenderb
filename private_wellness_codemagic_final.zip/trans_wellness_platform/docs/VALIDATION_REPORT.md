# Validation Report

- TRANS MEN: 750/750 questions present (`TM-001` through `TM-750`).
- TRANS WOMEN: 750/750 questions present (`TW-001` through `TW-750`).
- MENTAL HEALTH: 750/750 questions present (`MH-001` through `MH-750`).
- TOTAL: 2,250/2,250 questions present.
- Duplicate IDs: none.
- Missing IDs: none.
- Duplicate exact question text: none.
- Placeholder question sections: none.
- Every question includes an answer type: yes.
- Every question includes requirement level, AI eligibility, sensitivity, Prefer-not-to-answer flag, units and help text: yes.
- Sensitive questions flagged: 1050.
- Safety-critical questions flagged for crisis handling: 30.
- Crisis questions include routine-flow interruption metadata and prohibit graphic method detail: yes.
- Anatomy-aware branching metadata exists in anatomy/treatment-dependent sections: yes.
- AI estimates are specified as uncertain and non-prescriptive: yes.
- Invite-only account registration: yes; offline preview does not create an account or join community.
- Invitation tokens: exactly 35 characters, cryptographic RNG, hashed storage, one-time/expiring/revocable: yes.
- XXX maximum: 2.
- XX maximum: 3.
- X maximum: 4.

Automated validators: `tool/validate_question_bank.py` and `tool/validate_question_bank.dart`.
