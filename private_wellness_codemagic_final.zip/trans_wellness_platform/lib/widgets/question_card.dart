import 'package:flutter/material.dart';
import '../models/question.dart';

class QuestionCard extends StatefulWidget {
  const QuestionCard({super.key, required this.question, required this.onSave});
  final WellnessQuestion question;
  final Future<void> Function(dynamic value) onSave;

  @override State<QuestionCard> createState() => _QuestionCardState();
}

class _QuestionCardState extends State<QuestionCard> {
  final controller = TextEditingController();
  bool saving=false;
  @override void dispose(){ controller.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final q=widget.question;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal:16, vertical:8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
          Row(children:[
            Text(q.id, style: Theme.of(context).textTheme.labelLarge),
            const Spacer(),
            if(q.especiallySensitive) const Chip(label: Text('Sensitive')),
          ]),
          const SizedBox(height:8),
          Text(q.question, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height:8),
          Text(q.helpText, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height:12),
          TextField(
            controller: controller,
            minLines: 1, maxLines: 4,
            decoration: InputDecoration(labelText: q.answerType, hintText: q.units.isEmpty ? null : 'Units: ${q.units.join(' / ')}'),
          ),
          const SizedBox(height:8),
          Wrap(spacing:8, children:[
            FilledButton.tonal(onPressed:saving?null:() async { setState(()=>saving=true); await widget.onSave(controller.text); if(mounted){setState(()=>saving=false); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Saved privately on this device')));} }, child: Text(saving?'Saving…':'Save')),
            if(q.preferNotToAnswer) OutlinedButton(onPressed:() async => widget.onSave('Prefer not to answer'), child: const Text('Prefer not to answer')),
            OutlinedButton(onPressed:() async => widget.onSave('Skipped'), child: const Text('Skip')),
          ]),
        ]),
      ),
    );
  }
}
