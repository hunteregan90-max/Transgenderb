import 'package:flutter/material.dart';
import 'models/question.dart';
import 'services/api_client.dart';
import 'services/question_repository.dart';
import 'services/secure_vault.dart';
import 'screens/enrollment_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final questions = await QuestionRepository().load();
  final api = ApiClient();
  await api.restoreToken();
  runApp(WellnessApp(questions: questions, api: api, vault: SecureVault()));
}

class WellnessApp extends StatefulWidget {
  const WellnessApp({super.key, required this.questions, required this.api, required this.vault});
  final Map<String,List<WellnessQuestion>> questions; final ApiClient api; final SecureVault vault;
  @override State<WellnessApp> createState()=>_WellnessAppState();
}
class _WellnessAppState extends State<WellnessApp>{ bool inside=false, preview=false;
 @override Widget build(BuildContext context)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  title:'Private Wellness',
  themeMode:ThemeMode.system,
  theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.black,brightness:Brightness.light),useMaterial3:true,inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder())),
  darkTheme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.white,brightness:Brightness.dark),useMaterial3:true,inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder())),
  home: inside ? HomeScreen(questions:widget.questions,vault:widget.vault,preview:preview) : EnrollmentScreen(api:widget.api,onAuthenticated:()=>setState((){inside=true;preview=false;}),onPreview:()=>setState((){inside=true;preview=true;})),
 );
}
