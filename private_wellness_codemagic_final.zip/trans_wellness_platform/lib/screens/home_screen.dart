import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/secure_vault.dart';
import 'question_library_screen.dart';
import 'crisis_mode_screen.dart';
class HomeScreen extends StatelessWidget{
 const HomeScreen({super.key,required this.questions,required this.vault,required this.preview});
 final Map<String,List<WellnessQuestion>> questions; final SecureVault vault; final bool preview;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Private Wellness')),body:ListView(padding:const EdgeInsets.all(16),children:[
  if(preview) const Card(child:ListTile(leading:Icon(Icons.visibility_outlined),title:Text('Offline preview mode'),subtitle:Text('No community account exists. Invite-only registration remains enforced.'))),
  Text('Your private control center',style:Theme.of(c).textTheme.headlineMedium), const SizedBox(height:12),
  _tile(c,Icons.quiz_outlined,'Complete question library','2,250 structured questions with filtering and encrypted local answers',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>QuestionLibraryScreen(questions:questions,vault:vault)))),
  _tile(c,Icons.health_and_safety_outlined,'Crisis mode','Low-stimulation safety interface',()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const CrisisModeScreen()))),
  _tile(c,Icons.show_chart,'Transition dashboard','Measurements, HRT timeline, trends, photos and estimates',()=>_soon(c)),
  _tile(c,Icons.psychology_alt_outlined,'Mental-health dashboard','Mood, dissociation, sleep, coping and treatment trends',()=>_soon(c)),
  _tile(c,Icons.auto_awesome_outlined,'AI estimates','Trend-only estimates with uncertainty, missing-data and data-quality reporting',()=>_soon(c)),
  _tile(c,Icons.people_alt_outlined,'Private community','Profiles, groups, posts, DMs and moderation through the backend API',()=>_soon(c)),
  _tile(c,Icons.contacts_outlined,'Trusted contacts & safety plan','User-controlled support contacts and crisis preferences',()=>_soon(c)),
  _tile(c,Icons.lock_outline,'Privacy center','Encrypted local answer vault, selective sharing, export and deletion',()=>_soon(c)),
 ]));
 Widget _tile(BuildContext c,IconData i,String t,String s,VoidCallback onTap)=>Card(child:ListTile(leading:Icon(i),title:Text(t),subtitle:Text(s),trailing:const Icon(Icons.chevron_right),onTap:onTap));
 void _soon(BuildContext c)=>ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content:Text('Module scaffold included; connect UI to backend endpoints as you expand the production build.')));
}
