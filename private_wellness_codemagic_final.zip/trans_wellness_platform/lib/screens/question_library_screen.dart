import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/secure_vault.dart';
import '../widgets/question_card.dart';
class QuestionLibraryScreen extends StatefulWidget{
 const QuestionLibraryScreen({super.key,required this.questions,required this.vault});
 final Map<String,List<WellnessQuestion>> questions; final SecureVault vault;
 @override State<QuestionLibraryScreen> createState()=>_QuestionLibraryScreenState();
}
class _QuestionLibraryScreenState extends State<QuestionLibraryScreen>{
 String domain='trans_men', search=''; String? category;
 @override Widget build(BuildContext c){
  final source=widget.questions[domain]??[];
  final categories=source.map((q)=>q.category).toSet().toList();
  final filtered=source.where((q)=>(category==null||q.category==category)&&(search.isEmpty||q.id.toLowerCase().contains(search.toLowerCase())||q.question.toLowerCase().contains(search.toLowerCase()))).toList();
  return Scaffold(appBar:AppBar(title:const Text('Complete Question Library')),body:Column(children:[
   Padding(padding:const EdgeInsets.all(12),child:Wrap(spacing:8,runSpacing:8,children:[
    DropdownButton<String>(value:domain,items:const [DropdownMenuItem(value:'trans_men',child:Text('Trans men — 750')),DropdownMenuItem(value:'trans_women',child:Text('Trans women — 750')),DropdownMenuItem(value:'mental_health',child:Text('Mental health — 750'))],onChanged:(v)=>setState((){domain=v!;category=null;})),
    DropdownButton<String?>(value:category,hint:const Text('All sections'),items:[const DropdownMenuItem<String?>(value:null,child:Text('All sections')),...categories.map((e)=>DropdownMenuItem(value:e,child:Text(e)))],onChanged:(v)=>setState(()=>category=v)),
   ])),
   Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search questions'),onChanged:(v)=>setState(()=>search=v))),
   Padding(padding:const EdgeInsets.all(8),child:Text('${filtered.length} questions shown')),
   Expanded(child:ListView.builder(itemCount:filtered.length,itemBuilder:(c,i)=>QuestionCard(question:filtered[i],onSave:(v)=>widget.vault.writeAnswer(filtered[i].id,v)))),
  ]));
 }
}
