import 'package:flutter/material.dart';
class CrisisModeScreen extends StatelessWidget{
 const CrisisModeScreen({super.key});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Crisis Mode')),body:ListView(padding:const EdgeInsets.all(20),children:[
  Text('Choose one small next step',style:Theme.of(c).textTheme.headlineMedium), const SizedBox(height:12),
  const Text('If you may act on suicidal or self-harm thoughts, or cannot stay safe, seek immediate in-person help or contact emergency services in your location. This app is not emergency care.'),
  const SizedBox(height:16),
  for(final s in const ['I need grounding','I need someone to talk to','Show my safety plan','Call my trusted contact','Text my trusted contact','Show crisis resources','I am not safe right now','Help me get to a safer place','Show my reasons for living','Guide me through the next five minutes'])
   Card(child:ListTile(title:Text(s),trailing:const Icon(Icons.chevron_right),onTap:()=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$s — connect this action to your saved safety plan/contact settings.'))))),
 ]));
}
