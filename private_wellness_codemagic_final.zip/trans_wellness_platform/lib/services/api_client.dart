import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiClient {
  ApiClient({this.baseUrl = const String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000')});
  final String baseUrl;
  final _secure = const FlutterSecureStorage();
  String? _token;

  Future<void> restoreToken() async => _token = await _secure.read(key: 'auth_token');

  Future<Map<String, dynamic>> register({required String invite, required String username, required String password, required String displayName}) async {
    final r = await http.post(Uri.parse('$baseUrl/auth/register'), headers: {'content-type':'application/json'}, body: jsonEncode({
      'invite_code': invite, 'username': username, 'password': password, 'display_name': displayName,
    }));
    final body = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode >= 400) throw Exception(body['detail'] ?? 'Registration failed');
    _token = body['access_token'] as String;
    await _secure.write(key: 'auth_token', value: _token);
    return body;
  }

  Future<Map<String, dynamic>> login(String username, String password) async {
    final r = await http.post(Uri.parse('$baseUrl/auth/login'), headers: {'content-type':'application/json'}, body: jsonEncode({'username':username,'password':password}));
    final body = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode >= 400) throw Exception(body['detail'] ?? 'Login failed');
    _token = body['access_token'] as String;
    await _secure.write(key: 'auth_token', value: _token);
    return body;
  }

  Future<Map<String,dynamic>> me() async {
    if (_token == null) throw Exception('Not authenticated');
    final r = await http.get(Uri.parse('$baseUrl/me'), headers: {'authorization':'Bearer $_token'});
    if (r.statusCode >= 400) throw Exception('Session unavailable');
    return Map<String,dynamic>.from(jsonDecode(r.body) as Map);
  }

  Future<void> logout() async { _token = null; await _secure.delete(key:'auth_token'); }
}
