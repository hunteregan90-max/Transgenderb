import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';

class SecureVault {
  static const _keyName = 'answer_vault_key_v1';
  final _secure = const FlutterSecureStorage();
  final _cipher = AesGcm.with256bits();

  Future<SecretKey> _key() async {
    final existing = await _secure.read(key: _keyName);
    if (existing != null) return SecretKey(base64Url.decode(existing));
    final key = await _cipher.newSecretKey();
    final bytes = await key.extractBytes();
    await _secure.write(key: _keyName, value: base64UrlEncode(bytes));
    return key;
  }

  Future<File> _file() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/wellness_answers.vault');
  }

  Future<Map<String, dynamic>> readAll() async {
    final file = await _file();
    if (!await file.exists()) return {};
    try {
      final payload = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      final box = SecretBox(
        base64Url.decode(payload['ciphertext'] as String),
        nonce: base64Url.decode(payload['nonce'] as String),
        mac: Mac(base64Url.decode(payload['mac'] as String)),
      );
      final clear = await _cipher.decrypt(box, secretKey: await _key());
      return Map<String, dynamic>.from(jsonDecode(utf8.decode(clear)) as Map);
    } catch (_) {
      return {};
    }
  }

  Future<void> writeAnswer(String id, dynamic value) async {
    final all = await readAll();
    all[id] = {'value': value, 'updated_at': DateTime.now().toUtc().toIso8601String()};
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(
      Uint8List.fromList(utf8.encode(jsonEncode(all))),
      secretKey: await _key(),
      nonce: nonce,
    );
    final file = await _file();
    await file.parent.create(recursive: true);
    await file.writeAsString(jsonEncode({
      'ciphertext': base64UrlEncode(box.cipherText),
      'nonce': base64UrlEncode(box.nonce),
      'mac': base64UrlEncode(box.mac.bytes),
    }));
  }

  Future<void> clear() async {
    final file = await _file();
    if (await file.exists()) await file.delete();
  }
}
