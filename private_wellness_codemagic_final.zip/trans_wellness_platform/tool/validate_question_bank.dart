import 'dart:convert';
import 'dart:io';
void main(){
 final f=File('assets/questions/questions.json');
 if(!f.existsSync()){stderr.writeln('Question bank missing');exit(1);} 
 final data=jsonDecode(f.readAsStringSync()) as Map<String,dynamic>;
 final expected={'trans_men':'TM','trans_women':'TW','mental_health':'MH'};
 final allIds=<String>{}; final allTexts=<String>{};
 for(final e in expected.entries){
  final list=(data[e.key] as List).cast<Map>();
  if(list.length!=750){stderr.writeln('${e.key}: expected 750, got ${list.length}');exit(2);} 
  final counts=<String,int>{}; for(final item in list){final c=item['category'] as String; counts[c]=(counts[c]??0)+1;} if(counts.length!=25 || counts.values.any((n)=>n!=30)){stderr.writeln('${e.key}: expected 25 sections x 30');exit(8);} 
  for(var i=0;i<750;i++){
   final q=Map<String,dynamic>.from(list[i]); final id='${e.value}-${(i+1).toString().padLeft(3,'0')}';
   if(q['id']!=id){stderr.writeln('ID mismatch $id vs ${q['id']}');exit(3);} 
   for(final k in ['question','category','answer_type','answer_requirement','ai_estimate_eligible','especially_sensitive','prefer_not_to_answer','units','help_text','branching']){if(!q.containsKey(k)){stderr.writeln('$id missing $k');exit(4);}}
   if(!allIds.add(q['id'] as String)){stderr.writeln('duplicate id ${q['id']}');exit(5);} if(!allTexts.add(q['question'] as String)){stderr.writeln('duplicate question ${q['id']}');exit(6);} 
  }
 }
 if(allIds.length!=2250){stderr.writeln('Expected 2250 total');exit(7);} 
 stdout.writeln('VALID: 750 TM + 750 TW + 750 MH = 2250 unique complete questions');
}
