# Private Wellness — Codemagic-ready Flutter + FastAPI starter

This repository is a buildable cross-platform Flutter starter for a **private invite-only transgender wellness + trauma-informed mental-health tracking + community platform**. It includes the exact 2,250-question bank requested: **750 trans men + 750 trans women + 750 trauma/mental-health**, plus encrypted local answer storage and a FastAPI backend scaffold for invitations, membership IDs, ranks, responses, posts, reports, and audit events.

## What is implemented now

- Flutter app entry flow with invite-only registration/login plus a non-account offline preview.
- Complete searchable 2,250-question library bundled as JSON and CSV.
- Every question has ID, category, answer type, requirement level, AI eligibility, sensitivity flag, Prefer-not-to-answer support flag, units, help text, and branching metadata.
- Encrypted local answer vault using AES-GCM with the vault key stored in platform secure storage.
- Low-stimulation Crisis Mode surface.
- FastAPI backend with one-time 35-character cryptographically random invitation codes stored only by hash, expiration/revocation, failed-attempt throttling, sequential immutable membership numbers, password hashing, JWT sessions, encrypted questionnaire responses, audit logs, posts and reports.
- Rank caps: XXX=2, XX=3, X=4.
- Codemagic Android and iOS workflows.
- CI validation that fails unless the bank is exactly 750/750/750 with contiguous IDs and no duplicate question text.

## Important scope boundary

This is a serious functional **starter/MVP architecture**, not a claim that every social, clinician, photo-analysis, moderation, AI, notification, file-vault, export, passkey, push-notification, or production-compliance feature in the mega-spec is finished. Those modules are documented in `docs/PRODUCT_SPEC.md` and have backend/UI extension points. Security and medical/privacy compliance require deployment-specific threat modeling, legal review, penetration testing, app-store review, and clinical review before handling real sensitive data at scale.

## Build with Codemagic

1. Upload this entire repository to GitHub.
2. Add the GitHub repository in Codemagic.
3. Codemagic detects the root `codemagic.yaml` automatically.
4. Set `API_BASE_URL` in the Codemagic environment if the mobile app should reach your deployed backend.
5. Run **Android APK + AAB** for Android artifacts.
6. Run **iOS unsigned build** to verify iOS compilation. A distributable `.ipa` requires Apple signing credentials/provisioning in Codemagic.

Android uses APK/AAB. iOS does **not** use APK; iOS distribution uses a signed IPA/App Store archive.

## Local bootstrap

If you have Flutter installed:

```bash
flutter create --platforms=android,ios --org com.privatewellness .
flutter pub get
dart run tool/validate_question_bank.dart
flutter run --dart-define=API_BASE_URL=http://YOUR_SERVER:8000
```

Backend:

```bash
cp .env.example .env
# replace secrets before use
docker compose up --build
```

The bootstrap endpoint intentionally creates only an owner database record; production owner credential provisioning should be implemented as a controlled setup flow rather than embedding a default password.

## Medical and crisis safety

The app is for tracking, education, organization, reflection, and communication support. It is not a substitute for clinicians or emergency care. AI trend features must not diagnose, determine medication doses, or promise transition outcomes. Self-harm and suicide sections avoid graphic method detail and should interrupt normal questionnaire flow when immediate danger is indicated.
